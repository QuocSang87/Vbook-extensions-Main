function execute() {
    return Response.success([
        {
            title: "Truyện nổi bật",
            input: "https://dasactruyen.xyz/",
            script: "homecontent"
        }
    ]);
}
