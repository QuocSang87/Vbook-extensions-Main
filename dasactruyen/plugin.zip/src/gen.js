function execute() {
    return Response.success([
        {
            title: "Harem",
            input: "https://dasactruyen.xyz/index.php/the-loai/harem/",
            script: "genrecontent"
        },
        {
            title: "Cổ trang",
            input: "https://dasactruyen.xyz/index.php/the-loai/co-trang/",
            script: "genrecontent"
        },
        {
            title: "Incest",
            input: "https://dasactruyen.xyz/index.php/the-loai/incest/",
            script: "genrecontent"
        },
        {
            title: "Cuckold",
            input: "https://dasactruyen.xyz/index.php/the-loai/cuckold/",
            script: "genrecontent"
        }
    ]);
}