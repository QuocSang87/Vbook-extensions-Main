function execute() {
    return Response.success([
        {
            title: "Tất cả truyện",
            input: "https://dasactruyen.xyz/",
            script: "genrecontent"
        },
        {
            title: "Harem",
            input: "https://dasactruyen.xyz/?s=harem",
            script: "genrecontent"
        },
        {
            title: "Cổ trang",
            input: "https://dasactruyen.xyz/?s=cổ+trang",
            script: "genrecontent"
        },
        {
            title: "Incest",
            input: "https://dasactruyen.xyz/?s=incest",
            script: "genrecontent"
        },
        {
            title: "Cuckold",
            input: "https://dasactruyen.xyz/?s=cuckold",
            script: "genrecontent"
        },
        {
            title: "BDSM",
            input: "https://dasactruyen.xyz/?s=bdsm",
            script: "genrecontent"
        },
        {
            title: "Bách hợp",
            input: "https://dasactruyen.xyz/?s=bách+hợp",
            script: "genrecontent"
        },
        {
            title: "Đam mỹ",
            input: "https://dasactruyen.xyz/?s=đam+mỹ",
            script: "genrecontent"
        },
        {
            title: "Dân Quốc",
            input: "https://dasactruyen.xyz/?s=dân+quốc",
            script: "genrecontent"
        },
        {
            title: "Đồng nhân",
            input: "https://dasactruyen.xyz/?s=đồng+nhân",
            script: "genrecontent"
        },
        {
            title: "Fantasy",
            input: "https://dasactruyen.xyz/?s=fantasy",
            script: "genrecontent"
        },
        {
            title: "Giả tưởng",
            input: "https://dasactruyen.xyz/?s=giả+tưởng",
            script: "genrecontent"
        },
        {
            title: "Hiện đại",
            input: "https://dasactruyen.xyz/?s=hiện+đại",
            script: "genrecontent"
        },
        {
            title: "Khoa học viễn tưởng",
            input: "https://dasactruyen.xyz/?s=khoa+học+viễn+tưởng",
            script: "genrecontent"
        },
        {
            title: "Mặt trời",
            input: "https://dasactruyen.xyz/?s=mặt+trời",
            script: "genrecontent"
        },
        {
            title: "Ngôn tình",
            input: "https://dasactruyen.xyz/?s=ngôn+tình",
            script: "genrecontent"
        },
        {
            title: "Phiêu lưu",
            input: "https://dasactruyen.xyz/?s=phiêu+lưu",
            script: "genrecontent"
        },
        {
            title: "Quân sự",
            input: "https://dasactruyen.xyz/?s=quân+sự",
            script: "genrecontent"
        },
        {
            title: "Thể thao",
            input: "https://dasactruyen.xyz/?s=thể+thao",
            script: "genrecontent"
        },
        {
            title: "Trọng sinh",
            input: "https://dasactruyen.xyz/?s=trọng+sinh",
            script: "genrecontent"
        },
        {
            title: "Xuyên không",
            input: "https://dasactruyen.xyz/?s=xuyên+không",
            script: "genrecontent"
        }
    ]);
}
